plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "dev.firebread.quietbridge"
    compileSdk = 35

    defaultConfig {
        applicationId = "dev.firebread.quietbridge"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0-alpha"
    }
}

dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
}
