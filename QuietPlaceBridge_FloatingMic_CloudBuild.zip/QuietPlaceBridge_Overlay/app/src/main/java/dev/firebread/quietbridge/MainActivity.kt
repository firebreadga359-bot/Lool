package dev.firebread.quietbridge

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.net.Uri
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var chatX: EditText
    private lateinit var chatY: EditText
    private lateinit var threshold: EditText
    private val shizukuRequest = 51

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("bridge", MODE_PRIVATE)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 24, 28, 24) }
        layout.addView(TextView(this).apply { text = "🎙 Quiet Place Mic Bridge"; textSize = 24f })
        layout.addView(TextView(this).apply { text = "Measures actual microphone RMS and attempts to send numeric levels to the Minecraft add-on. This is experimental: the bridge types commands into chat, so the chat UI may open repeatedly."; textSize = 16f })
        chatX = field("Minecraft chat button X pixel", prefs.getString("x", "45") ?: "45")
        chatY = field("Minecraft chat button Y pixel", prefs.getString("y", "45") ?: "45")
        threshold = field("Raw mic RMS threshold (default 0.024)", prefs.getString("threshold", "0.024") ?: "0.024")
        listOf(chatX, chatY, threshold).forEach { layout.addView(it) }
        layout.addView(TextView(this).apply { text = "The mic meter appears in the add-on HUD. For one-player worlds the receiver targets the only player. Coordinates 45,45 are only a guess; calibrate them first. Do not use in a valuable world until tested." })
        layout.addView(TextView(this).apply { text = if (Shizuku.pingBinder()) "Shizuku service detected" else "Shizuku not connected — activate it first" })
        layout.addView(Button(this).apply { text = "START MIC METER"; setOnClickListener { startBridge(prefs) } })
        layout.addView(Button(this).apply { text = "STOP MIC METER"; setOnClickListener { stopService(Intent(this@MainActivity, MicBridgeService::class.java)) } })
        layout.addView(Button(this).apply {
            text = "SHOW FLOATING 🎙 BUTTON"
            setOnClickListener {
                val x = chatX.text.toString().toIntOrNull()
                val y = chatY.text.toString().toIntOrNull()
                val t = threshold.text.toString().toFloatOrNull()
                if (x == null || y == null || t == null || t <= 0f) {
                    Toast.makeText(this@MainActivity, "Check coordinates and threshold", Toast.LENGTH_LONG).show()
                } else {
                    prefs.edit().putString("x", "$x").putString("y", "$y").putString("threshold", "$t").apply()
                    if (!Settings.canDrawOverlays(this@MainActivity)) {
                        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
                        Toast.makeText(this@MainActivity, "Allow display over other apps, then return and tap SHOW FLOATING BUTTON again.", Toast.LENGTH_LONG).show()
                    } else {
                        val overlay = Intent(this@MainActivity, FloatingMicService::class.java)
                        if (Build.VERSION.SDK_INT >= 26) startForegroundService(overlay) else startService(overlay)
                        Toast.makeText(this@MainActivity, "Floating mic button shown", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        })
        layout.addView(TextView(this).apply { text = "Setup: enable the behavior pack/script in a backup world; activate Shizuku; grant Shizuku and microphone permission; calibrate chat coordinates; start the bridge and return to Minecraft. No player-to-player voice chat and no remote server." })
        setContentView(ScrollView(this).apply { addView(layout, ViewGroup.LayoutParams(-1, -2)) })
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
    }

    private fun field(label: String, value: String) = EditText(this).apply { hint = label; setText(value); singleLine = true; contentDescription = label }

    private fun startBridge(prefs: android.content.SharedPreferences) {
        val x = chatX.text.toString().toIntOrNull(); val y = chatY.text.toString().toIntOrNull(); val t = threshold.text.toString().toFloatOrNull()
        if (x == null || y == null || t == null || t <= 0f) { Toast.makeText(this, "Check coordinates and threshold", Toast.LENGTH_LONG).show(); return }
        prefs.edit().putString("x", "$x").putString("y", "$y").putString("threshold", "$t").apply()
        if (!Shizuku.pingBinder()) { Toast.makeText(this, "Activate Shizuku first", Toast.LENGTH_LONG).show(); return }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) { Shizuku.requestPermission(shizukuRequest); return }
        val intent = Intent(this, MicBridgeService::class.java).putExtra("x", x).putExtra("y", y).putExtra("threshold", t)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        Toast.makeText(this, "Mic measurement started — return to Minecraft", Toast.LENGTH_LONG).show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == shizukuRequest && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            val prefs = getSharedPreferences("bridge", MODE_PRIVATE)
            startBridge(prefs)
        }
    }
}
