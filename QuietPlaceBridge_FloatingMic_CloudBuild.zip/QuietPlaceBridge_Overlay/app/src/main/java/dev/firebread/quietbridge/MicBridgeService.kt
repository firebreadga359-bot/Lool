package dev.firebread.quietbridge

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.util.Log
import rikka.shizuku.Shizuku
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.sqrt

/** Experimental local bridge. It measures mic RMS, then injects Bedrock chat commands via Shizuku. */
class MicBridgeService : Service() {
    @Volatile private var running = false
    @Volatile private var speaking = false
    private var recorder: AudioRecord? = null
    private var chatX = 45
    private var chatY = 45
    // RMS threshold. Speech is commonly around 0.02-0.10, but device mics vary.
    private var threshold = 0.024f
    private var lastCommandAt = 0L
    private var lastBucket = -1

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        chatX = intent?.getIntExtra("x", chatX) ?: chatX
        chatY = intent?.getIntExtra("y", chatY) ?: chatY
        threshold = intent?.getFloatExtra("threshold", threshold) ?: threshold
        startForeground(42, notification())
        if (!running) { running = true; thread(name = "QuietPlaceMicMeter") { monitorMic() } }
        return START_NOT_STICKY
    }

    private fun notification(): Notification {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel("mic_bridge", "Quiet Place microphone", NotificationManager.IMPORTANCE_LOW))
        return if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, "mic_bridge").setContentTitle("Quiet Place mic is measuring").setContentText("Keep Minecraft open. Stop from the bridge app.").setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
        else Notification.Builder(this).setContentTitle("Quiet Place mic is measuring").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
    }

    private fun monitorMic() {
        val rate = 16000
        val minBuffer = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuffer <= 0) { Log.e("QuietBridge", "AudioRecord buffer unsupported: $minBuffer"); running = false; stopSelf(); return }
        val audio = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuffer, 4096))
        recorder = audio
        try {
            if (audio.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("Microphone could not initialize")
            audio.startRecording()
            val buffer = ShortArray(1024)
            while (running) {
                val n = audio.read(buffer, 0, buffer.size)
                if (n > 0) {
                    var sum = 0.0
                    for (i in 0 until n) { val v = buffer[i].toDouble() / 32768.0; sum += v * v }
                    val rms = sqrt(sum / n).toFloat()
                    // Scale RMS to a useful 0..1 display value; actual microphone amplitude is device-dependent.
                    val level = (rms * 5.0f).coerceIn(0.0f, 1.0f)
                    val nextSpeaking = rms >= threshold
                    val bucket = (level * 10).toInt() // 10% meter buckets to reduce chat spam
                    val now = System.currentTimeMillis()
                    val stateChanged = nextSpeaking != speaking
                    val levelChanged = bucket != lastBucket
                    // Bedrock retail has no public socket API for add-on events. Each update is typed into chat,
                    // so throttle aggressively; chat may visibly open and close during a live meter update.
                    if ((stateChanged || levelChanged) && now - lastCommandAt >= 1400L) {
                        speaking = nextSpeaking
                        lastBucket = bucket
                        lastCommandAt = now
                        sendMicLevel(level, nextSpeaking)
                    }
                }
                Thread.sleep(35)
            }
        } catch (e: Exception) { Log.e("QuietBridge", "Mic detector failed", e) }
        finally { try { audio.stop() } catch (_: Exception) {}; audio.release(); recorder = null; running = false }
    }

    private fun sendMicLevel(level: Float, isSpeaking: Boolean) {
        if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            Log.w("QuietBridge", "Shizuku unavailable or permission missing; mic level not delivered"); return
        }
        val number = String.format(Locale.US, "%.2f", level)
        val command = "/scriptevent quietplace:mic level=$number"
        // Shell input is local. Coordinates must be calibrated for the current Minecraft UI.
        thread(name = "QuietPlaceCommandSender") {
            try {
                val shell = "input tap $chatX $chatY; sleep 0.30; input text '${command.replace(" ", "%s")}' ; sleep 0.12; input keyevent 66"
                val process = Shizuku.newProcess(arrayOf("sh", "-c", shell), null, null)
                val code = process.waitFor()
                Log.i("QuietBridge", "Delivered mic level=$number speaking=$isSpeaking exit=$code")
            } catch (e: Exception) { Log.e("QuietBridge", "Could not inject mic level into Minecraft chat", e) }
        }
    }

    override fun onDestroy() {
        running = false
        try { recorder?.stop() } catch (_: Exception) {}
        super.onDestroy()
    }
}
