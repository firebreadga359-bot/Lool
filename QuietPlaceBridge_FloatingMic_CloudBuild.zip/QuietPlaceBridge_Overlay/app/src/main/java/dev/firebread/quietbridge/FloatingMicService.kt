package dev.firebread.quietbridge

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.Toast

/** Floating control over Minecraft. The button starts/stops the mic bridge; it does not itself add mic access to Bedrock. */
class FloatingMicService : Service() {
    private lateinit var wm: WindowManager
    private var button: Button? = null
    private var active = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'Display over other apps' for Quiet Place Bridge, then try again.", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = Button(this).apply {
            text = "🎙"
            textSize = 20f
            contentDescription = "Toggle Quiet Place microphone bridge"
            setOnClickListener { toggleMic() }
            setOnTouchListener(object : android.view.View.OnTouchListener {
                var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
                var moved = false
                override fun onTouch(v: android.view.View, event: MotionEvent): Boolean {
                    val lp = v.layoutParams as WindowManager.LayoutParams
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = lp.x; startY = lp.y; moved = false; return true }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = (event.rawX - downX).toInt(); val dy = (event.rawY - downY).toInt()
                            if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true
                            lp.x = startX + dx; lp.y = startY + dy
                            wm.updateViewLayout(v, lp); return true
                        }
                        MotionEvent.ACTION_UP -> {
                            if (!moved) v.performClick()
                            return true
                        }
                    }
                    return false
                }
            })
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 140 }
        button = b
        wm.addView(b, lp)
    }

    private fun toggleMic() {
        if (active) {
            stopService(Intent(this, MicBridgeService::class.java))
            active = false
            button?.text = "🎙"
            Toast.makeText(this, "Mic bridge stopped", Toast.LENGTH_SHORT).show()
        } else {
            val prefs = getSharedPreferences("bridge", MODE_PRIVATE)
            val x = prefs.getString("x", "45")?.toIntOrNull() ?: 45
            val y = prefs.getString("y", "45")?.toIntOrNull() ?: 45
            val threshold = prefs.getString("threshold", "0.024")?.toFloatOrNull() ?: 0.024f
            val i = Intent(this, MicBridgeService::class.java).putExtra("x", x).putExtra("y", y).putExtra("threshold", threshold)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            active = true
            button?.text = "🔴"
            Toast.makeText(this, "Mic bridge started; tap again to stop", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        try { button?.let { wm.removeView(it) } } catch (_: Exception) {}
        button = null
        super.onDestroy()
    }
}
